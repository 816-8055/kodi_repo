# -*- coding: utf-8 -*-
# Module: default
# Author: 816_8055
# Created on: 2018-12-20
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import sys
from urllib import urlencode, urlopen
from urlparse import parse_qsl
import json
import xbmcgui
import xbmcplugin

_url = sys.argv[0]
_handle = int(sys.argv[1])

ICON = 'https://www.hopechannel.de/fileadmin/HopeChannel/Design1/Images/Favicons/favicon-194x194.png'
MAIN = {'tv_live':       {'info': {'title': 'HopeChannel Live TV', 'mediatype': 'video'},
                          'art': {}},
        'tv_library':    {'info': {'title': 'HopeChannel TV Media Library',
                                   'mediatype': 'video'},
                          'art': {}},
        'radio_library': {'info': {'title': 'HopeChannel Radio Media Library',
                                   'mediatype': 'music'},
                          'art': {}}
        }


def get_url(**kwargs):
    return '{0}?{1}'.format(_url, urlencode(kwargs))


def list_main():
    #xbmcplugin.setPluginCategory(_handle, 'HopeChannel')
    xbmcplugin.setContent(_handle, 'videos')
    for main in MAIN:
        info = MAIN[main]['info']
        list_item = xbmcgui.ListItem(label=info['title'])
        list_item.setInfo('video', info)
        art = MAIN[main]['art']
        if art:
            list_item.setArt(art)
        url = get_url(action='listing', main=main)
        is_folder = True
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_handle)


def list_streams():
    xbmcplugin.setPluginCategory(_handle, 'Live TV')
    xbmcplugin.setContent(_handle, 'videos')
    streams = json.loads(urlopen('http://database.hopetv.org/api?type=streams&lang=de&device=ios_react_native_phone').read())
    for stream in streams:
        list_item = xbmcgui.ListItem(label=stream['title'])
        list_item.setInfo('video', {'title': stream['title'],
                                    'plot': stream['description'],
                                    'mediatype': 'video'})
        if stream.get('thumbnail', 0):
            url = 'http://database.hopetv.org/typo3temp/tx_amsmedialibrary/ios_react_native_phone_s{}.jpg'.format(video['uid'])
        else: url = ICON
        list_item.setArt({'thumb': url, 
                          'icon': url,
                          'fanart': url})
        list_item.setProperty('IsPlayable', 'true')
        url = get_url(action='play', stream=stream['stream'])
        is_folder = False
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_handle)


def list_libraries(medium):
    xbmcplugin.setPluginCategory(_handle, '{} Media Library'.format(medium))
    xbmcplugin.setContent(_handle, 'videos')
    data = json.loads(urlopen('http://database.hopetv.org/api?type=libraries&device=ios_react_native_phone&lang=de').read())
    libraries = filter(lambda x: x['type'] == medium.lower(), data['libraries'])
    for library in libraries:
        list_item = xbmcgui.ListItem(label=library['title'])
        list_item.setArt({'thumb': ICON,
                          'icon': ICON})
        list_item.setInfo('video', {'title': library['title'],
                                    'plot': library['description'],
                                    'mediatype': 'video'})
        url = get_url(action='listing', library=library['uid'],
                      title=library['title'].encode('utf-8'))
        is_folder = True
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_handle)


def list_shows(library, title):
    xbmcplugin.setPluginCategory(_handle, title)
    xbmcplugin.setContent(_handle, 'videos')
    data = json.loads(urlopen('http://database.hopetv.org/api?type=shows&device=ios_react_native_phone&lang=de&library={}'.format(library)).read())
    shows = data['shows']
    for show in shows:
        list_item = xbmcgui.ListItem(label=show['title'])
        list_item.setInfo('video', {'title': show['title'],
                                    'plot': show['description'],
                                    'mediatype': 'video'})
        if show.get('thumbnail', 0):
            url = 'http://database.hopetv.org/typo3temp/tx_amsmedialibrary/ios_react_native_phone_s{}.jpg'.format(show['uid'])
        else:
            url = ICON
        list_item.setArt({'thumb': url, 
                          'icon': url,
                          'fanart': url})
        url = get_url(action='listing', show=show['uid'],
                      library=library, title=show['title'].encode('utf-8'))
        is_folder = True
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_handle)


def list_mediastories(library, show, title):
    xbmcplugin.setPluginCategory(_handle, title)
    xbmcplugin.setContent(_handle, 'videos')
    data = json.loads(urlopen('http://database.hopetv.org/api?type=mediastories&device=ios_react_native_phone&lang=de&library={}&show={}'.format(library, show)).read())
    videos = data['mediastories']
    for video in videos:
        list_item = xbmcgui.ListItem(label=video['title'])
        list_item.setInfo('video', {'title': video['title'],
                                    'plot': video['description'],
                                    'mediatype': 'video'})
        if video.get('thumbnail', 0):
            url = 'http://database.hopetv.org/typo3temp/tx_amsmedialibrary/ios_react_native_phone_m{}.jpg'.format(video['uid'])
            list_item.setArt({'thumb': url, 
                              'icon': url,
                              'fanart': url})
        list_item.setProperty('IsPlayable', 'true')
        url = get_url(action='play', stream=video['media'])
        is_folder = False
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_handle)


def play_video(path):
    play_item = xbmcgui.ListItem(path=path)
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        if params['action'] == 'listing':
            if 'main' in params:
                if params['main'] == 'tv_live':
                    list_streams()
                elif params['main'] == 'tv_library':
                    list_libraries('TV')
                elif params['main'] == 'radio_library':
                    list_libraries('Radio')
                return
            if 'show' in params:
                list_mediastories(params['library'], params['show'], params['title'])
                return
            if 'library' in params:
                list_shows(params['library'], params['title'])
                return
        elif params['action'] == 'play':
            play_video(params['stream'])
        else:
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
        list_main()


if __name__ == '__main__':
    router(sys.argv[2][1:])
