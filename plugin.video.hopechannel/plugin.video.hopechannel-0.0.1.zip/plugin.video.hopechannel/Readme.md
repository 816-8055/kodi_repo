Kodi Plugin to watch HopeChannel Live Stream, or to browse Media Library.
License: [GPL v.3](http://www.gnu.org/copyleft/gpl.html)
